# a8-sprite-editor-f19-tmjdotedu
a8-sprite-editor-f19-tmjdotedu created by GitHub Classroom

Built for Windows 10 by The Task Managers.